package com.ws.manga.Mangas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MangasApplication {

	public static void main(String[] args) {
		SpringApplication.run(MangasApplication.class, args);
	}

}
